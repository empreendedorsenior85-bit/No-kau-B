import type { Metadata, Viewport } from "next";
import { Inter, Playfair_Display } from "next/font/google";
import { MotionProvider } from "@/components/motion/MotionProvider";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { MobileActionBar } from "@/components/layout/MobileActionBar";
import { site } from "@/lib/site";
import "./globals.css";

const inter = Inter({ variable: "--font-inter", subsets: ["latin"], display: "swap" });
const playfair = Playfair_Display({ variable: "--font-playfair", subsets: ["latin"], style: ["normal", "italic"], display: "swap" });

export const metadata: Metadata = {
  metadataBase: new URL(site.siteUrl),
  title: { default: "Nô Kau — Restaurante Grill, Bar & Karaoke em Bissau", template: "%s · Nô Kau" },
  description:
    "Onde a gastronomia encontra a cultura. Grill, bar, cocktails, música ao vivo e karaoke na Rua 7, em Bissau, Guiné-Bissau.",
  applicationName: "Nô Kau",
  openGraph: { type: "website", locale: "pt_PT", siteName: "Nô Kau" },
  twitter: { card: "summary_large_image" },
  formatDetection: { telephone: true },
};

export const viewport: Viewport = { themeColor: "#151109", colorScheme: "dark" };

/** Dados estruturados apenas com factos confirmados (sem horário, sem avaliações). */
const jsonLd = {
  "@context": "https://schema.org",
  "@type": "Restaurant",
  name: site.name,
  description: site.tagline,
  telephone: site.phoneE164,
  url: site.siteUrl,
  image: `${site.siteUrl}/brand/logo-nokau.png`,
  sameAs: [site.instagram],
  address: { "@type": "PostalAddress", streetAddress: site.street, addressLocality: site.city, addressCountry: site.country },
  acceptsReservations: true,
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang="pt-PT" className={`${inter.variable} ${playfair.variable} antialiased`} suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: "document.documentElement.classList.add('js')" }} />
      </head>
      <body className="min-h-svh">
        <a href="#conteudo" className="sr-only z-[60] rounded-full bg-gold px-4 py-2 text-kau-950 focus:not-sr-only focus:fixed focus:left-4 focus:top-4">
          Saltar para o conteúdo
        </a>
        <MotionProvider>
          <Header />
          <div id="conteudo">{children}</div>
          <Footer />
          <MobileActionBar />
        </MotionProvider>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd).replace(/</g, "\\u003c") }}
        />
      </body>
    </html>
  );
}
