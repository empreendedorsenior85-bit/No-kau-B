/** Preços em francos CFA (XOF), inteiros. Ex.: 6500 → "6 500 FCFA" conforme a locale. */
export function formatXOF(amount: number, locale = "pt-PT"): string {
  const n = new Intl.NumberFormat(locale, { maximumFractionDigits: 0, useGrouping: "always" }).format(amount);
  return `${n} FCFA`;
}
